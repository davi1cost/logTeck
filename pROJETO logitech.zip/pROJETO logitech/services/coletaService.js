const { AppError } = require("../erros");
const coletaRepository = require("../repositories/coletaRepository");

const coletaService = {
    async listar() {
        return coletaRepository.listar();
    },

    async atualizarStatus(id, status) {
        if (!id) {
            throw new AppError("O ID da coleta é obrigatório.", 400);
        }

        if (!status) {
            throw new AppError("O status da coleta é obrigatório.", 400);
        }

        return coletaRepository.atualizarStatus(id, status);
    }
};

module.exports = coletaService;