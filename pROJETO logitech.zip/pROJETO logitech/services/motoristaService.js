const { AppError } = require("../erros");
const motoristaRepository = require("../repositories/motoristaRepository");

const CAMPOS_OBRIGATORIOS = {
    nome: "O nome do motorista é obrigatório.",
    cpf: "O CPF do motorista é obrigatório.",
    telefone: "O telefone do motorista é obrigatório."
};

const motoristaService = {
    async cadastrar(dados = {}) {
        for (const [campo, mensagem] of Object.entries(CAMPOS_OBRIGATORIOS)) {
            if (!dados[campo]) {
                throw new AppError(mensagem, 400);
            }
        }

        return motoristaRepository.cadastrar(dados);
    },

    async listar() {
        return motoristaRepository.listar();
    }
};

module.exports = motoristaService;