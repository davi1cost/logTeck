const express = require("express");
const { tratarErros } = require("./erros");

const motoristaRoutes = require("./routes/motoristaRoutes");
const coletaRoutes = require("./routes/coletaRoutes");

const app = express();

app.use(express.json());

app.get("/", (req, res) => {
    res.json({ mensagem: "API LogiTech Express funcionando!" });
});

app.use("/motoristas", motoristaRoutes);
app.use("/coletas", coletaRoutes);

// Deve ficar depois das rotas
app.use(tratarErros);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});