// Erro com código HTTP associado
class AppError extends Error {
    constructor(mensagem, statusCode = 400) {
        super(mensagem);
        this.statusCode = statusCode;
    }
}

// Encaminha erros de funções async para o tratarErros
const asyncHandler = (fn) => (req, res, next) =>
    Promise.resolve(fn(req, res, next)).catch(next);

// Middleware central de tratamento de erros
const tratarErros = (erro, req, res, next) => {
    const status = erro.statusCode || 500;

    if (status === 500) {
        console.error(erro);
    }

    res.status(status).json({ erro: erro.message });
};

module.exports = { AppError, asyncHandler, tratarErros };