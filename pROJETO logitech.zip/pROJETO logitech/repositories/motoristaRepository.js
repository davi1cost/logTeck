const motoristaRepository = {
    async cadastrar(dados) {
        // TODO: implementar o INSERT no banco de dados.
        return {
            mensagem: "Motorista preparado para ser cadastrado.",
            dados
        };
    },

    async listar() {
        // TODO: implementar o SELECT no banco de dados.
        return [];
    }
};

module.exports = motoristaRepository;