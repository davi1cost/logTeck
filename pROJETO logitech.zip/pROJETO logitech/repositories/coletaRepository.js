const coletaRepository = {
    async listar() {
        // TODO: implementar o SELECT no banco de dados.
        return [];
    },

    async atualizarStatus(id, status) {
        // TODO: implementar o UPDATE no banco de dados.
        return { id, status };
    }
};

module.exports = coletaRepository;