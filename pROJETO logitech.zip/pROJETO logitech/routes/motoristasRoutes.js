const { Router } = require("express");
const { asyncHandler } = require("../erros");
const motoristaService = require("../services/motoristaService");

// ---------- Controller ----------
const controller = {
    async cadastrar(req, res) {
        const motorista = await motoristaService.cadastrar(req.body);
        res.status(201).json(motorista);
    },

    async listar(req, res) {
        const motoristas = await motoristaService.listar();
        res.status(200).json(motoristas);
    }
};

// ---------- Rotas ----------
const router = Router();

router.post("/", asyncHandler(controller.cadastrar)); // POST /motoristas
router.get("/", asyncHandler(controller.listar));     // GET  /motoristas

module.exports = router;