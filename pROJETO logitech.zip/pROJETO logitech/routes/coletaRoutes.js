const { Router } = require("express");
const { asyncHandler } = require("../erros");
const coletaService = require("../services/coletaService");

// ---------- Controller ----------
const controller = {
    async listar(req, res) {
        const coletas = await coletaService.listar();
        res.status(200).json(coletas);
    },

    async atualizarStatus(req, res) {
        const { id } = req.params;
        const { status } = req.body;

        const coleta = await coletaService.atualizarStatus(id, status);
        res.status(200).json(coleta);
    }
};

// ---------- Rotas ----------
const router = Router();

router.get("/", asyncHandler(controller.listar));                    // GET /coletas
router.put("/:id/status", asyncHandler(controller.atualizarStatus)); // PUT /coletas/:id/status

module.exports = router;